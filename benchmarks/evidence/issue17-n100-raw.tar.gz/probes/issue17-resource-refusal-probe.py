import importlib.util
import json
import sys
from pathlib import Path
import numpy as np
import pandas_booster._rust as rust
spec = importlib.util.spec_from_file_location('route_evidence', sys.argv[1])
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
role, agg, threads = sys.argv[2], sys.argv[3], int(sys.argv[4])
root = Path('/tmp/issue17-certified-' + role + '-v2')
runtime = json.loads((root / 'runtime-v3.json').read_text())
identity = d.validate_runtime(runtime, threads)
pre_input = d.rss()
n = 5_000_000
rng = np.random.RandomState(42)
keys = [np.arange(n, dtype=np.int64)] + [rng.randint(0, 2, n, dtype=np.int64) for _ in range(9)]
values = rng.randint(0, 10000, n, dtype=np.int64)
out_keys, out_values, profile = getattr(rust, 'profile_groupby_multi_' + agg + '_i64_sorted')(keys, values)
peak = d.rss()
assert profile['route'] == 'hash_first'
assert profile['route_reason'] == 'memory_limit'
assert profile['estimated_peak_bytes'] > 512 * 1024 * 1024
assert profile['hash_first_aggregation_count'] == 1
assert profile['post_aggregation_sort_count'] == 1
assert len(out_values) == n
for left, right in zip(out_keys, keys):
    np.testing.assert_array_equal(left, right)
if agg == 'max':
    np.testing.assert_array_equal(out_values, values)
else:
    assert np.all(out_values == 1)
print(json.dumps({'status': 'passed', 'diagnostic_only': True, 'whole_process_cap': False, 'kind': 'refused10_direct_kernel', 'n': n, 'agg': agg, 'threads': threads, 'identity': identity, 'pre_input': pre_input, 'rss': peak, 'profile': profile}))
