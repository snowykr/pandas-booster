"""Build a candidate-bound evidence receipt; never alter raw reports or verdicts."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import statistics
import tarfile

ROOT = Path('/tmp/pr20-recovery')
REPO = Path('/home/snowy/.gajaeway/lanes/70616e6461732d626f6f737465722d707232302d6761746573')
BASE = '291bc4af284119fd84e5408fd411dd6b4e0171d4'
CAND = '3828bb117451b7ce52e5c80f9631e319ba258295'
spec = importlib.util.spec_from_file_location('route', REPO/'benchmarks/route_evidence.py')
assert spec is not None and spec.loader is not None
route = importlib.util.module_from_spec(spec)
spec.loader.exec_module(route)


def load(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return route.digest(Path(path))


def capsule(descriptor):
    m = descriptor['manifest']
    return {k: descriptor[k] for k in ('python_identity', 'python', 'wheel', 'wheel_sha256', 'dependencies', 'purpose')} | {
        'source_sha': m['sha'], 'source_root': m['source_root'],
        'extension_sha256': descriptor['installed_files'][Path(descriptor['extension']).name],
        'dependency_lock_sha256': m['lock_sha256'], 'cargo_lock_sha256': m['cargo_lock_sha256'],
        'rustc': m['rustc'], 'cargo': m['cargo'], 'build_log_sha256': m['build_log_sha256'],
    }


names = ['sampler-primary-t1.json', 'sampler-primary-t2.json', 'sampler-primary-t4.json',
         'sampler-controls-t4.json', 'sampler-unsorted-t4.json', 'sampler-domains-t4.json',
         'sampler-memory-t1.json']
reports = {name: load(ROOT/name) for name in names}
performance, memory, raw_reports, profiles = [], [], [], []
seen_performance, seen_memory = set(), set()
all_raw = []
for name, report in reports.items():
    assert report['certified'] is False and report['status'] == 'DRAFT'
    assert report['runtimes']['baseline']['manifest']['sha'] == BASE
    assert report['runtimes']['candidate']['manifest']['sha'] == CAND
    raw_reports.append({'file': name, 'sha256': digest(ROOT/name), 'bytes': (ROOT/name).stat().st_size,
                        'observations': len(report['raw']), 'status': report['status'],
                        'unmet_gates_unchanged': report['unmet_gates']})
    for observation in report['raw']:
        assert 'error' not in observation and observation['result']['status'] == 'passed'
        assert observation['result']['identity']['sha'] == (CAND if observation['role'] == 'candidate' else BASE)
    all_raw.extend(report['raw'])
    for entry in report['summary']:
        case, threads, mode = entry['case'], entry['threads'], entry['mode']
        key = (case['name'], case['agg'], threads, mode)
        assert key not in seen_performance
        seen_performance.add(key)
        paired = {}
        for role in ('baseline', 'candidate'):
            observations = [o for o in report['raw'] if o['case'] == case and o['threads'] == threads and o['kind'] == mode and o['role'] == role]
            assert len(observations) == 40 and {o['pair'] for o in observations} == set(range(40))
            paired[role] = observations
        pairs = [{role: next(o['result']['elapsed_s'] for o in paired[role] if o['pair'] == i) for role in paired} for i in range(40)]
        recalculated = route.paired_summary(pairs)
        assert recalculated == {k: entry[k] for k in recalculated}
        threshold = 'not binding at this thread count'
        passed = None
        if threads == 4:
            if case['name'] == 'primary' and mode == 'warm':
                threshold = 'ratio<=0.90 AND U95<1.00'
                passed = entry['ratio'] <= .90 and entry['u95'] < 1
            else:
                threshold = 'U95<=1.05'
                passed = entry['u95'] <= 1.05
            assert passed
        item = {'report': name, 'case': case['name'], 'agg': case['agg'], 'rows': case['n'],
                'threads': threads, 'mode': mode, 'pairs': 40, 'ratio': entry['ratio'], 'u95': entry['u95'],
                'threshold': threshold, 'passed': passed}
        for role, observations in paired.items():
            item[role+'_median_s'] = statistics.median(o['result']['elapsed_s'] for o in observations)
            item[role+'_median_cpu_s'] = statistics.median(o['result']['cpu_s'] for o in observations)
            item[role+'_median_cpu_to_wall'] = statistics.median(o['result']['cpu_to_wall_ratio'] for o in observations)
        if case['name'] == 'primary' and threads == 4 and mode == 'warm':
            item['extra_conservative_U95_le_0_90'] = entry['u95'] <= .90
            assert item['extra_conservative_U95_le_0_90']
        performance.append(item)
    rss_keys = {(o['case']['name'], o['case']['agg'], o['threads']) for o in report['raw'] if o['kind'] == 'rss'}
    for key in sorted(rss_keys):
        assert key not in seen_memory
        seen_memory.add(key)
        observations = [o for o in report['raw'] if (o['case']['name'], o['case']['agg'], o['threads']) == key]
        role_rows = {role: [o for o in observations if o['kind'] == 'rss' and o['role'] == role] for role in ('baseline', 'candidate')}
        assert all(len(rows) == 10 for rows in role_rows.values())
        baseline_median = statistics.median(o['result']['rss']['VmHWM'] for o in role_rows['baseline'])
        example = role_rows['candidate'][0]
        case, threads = example['case'], example['threads']
        request = load(example['request'])
        input_bytes = request['dataset_manifest']['input_bytes']
        evidence = next(o['result'] for o in observations if o['kind'] == 'evidence' and o['role'] == 'candidate')
        profile = evidence.get('profile', {})
        admitted = case['name'] in ('primary', 'packed2', 'packed10', 'fused3')
        model = profile.get('estimated_peak_bytes')
        workers = []
        for o in role_rows['candidate']:
            result = o['result']
            measured_limit = 1.10 * baseline_median + 32 * route.MIB
            analytical_limit = None if model is None else result['pre_input']['VmRSS'] + input_bytes + model + 128*route.MIB + 8*route.MIB*threads
            envelope = None if analytical_limit is None else min(analytical_limit, measured_limit)
            gaps = None if model is None else route.memory_gaps(result, baseline_median, input_bytes, model, threads, admitted)
            assert result['rss']['VmHWM'] <= measured_limit
            if gaps is not None:
                assert gaps == []
            workers.append({'pair': o['pair'], 'pre_input_rss_bytes': result['pre_input']['VmRSS'],
                            'hwm_bytes': result['rss']['VmHWM'], 'measured_limit_bytes': measured_limit,
                            'analytical_limit_bytes': analytical_limit, 'envelope_bytes': envelope,
                            'headroom_bytes': None if envelope is None else envelope-result['rss']['VmHWM'],
                            'unchanged_memory_gaps': gaps})
        memory.append({'report': name, 'case': case['name'], 'agg': case['agg'], 'threads': threads,
                       'rows': case['n'], 'admitted': admitted, 'input_bytes': input_bytes,
                       'modeled_route_peak_bytes': model,
                       'model_scope': 'sort-first dispatch payload budget; NOT an allocator/fallback/process cap' if model is not None else 'UNKNOWN: unsorted allocator/live model unavailable',
                       'baseline_median_hwm_bytes': baseline_median,
                       'baseline_max_hwm_bytes': max(o['result']['rss']['VmHWM'] for o in role_rows['baseline']),
                       'candidate_max_hwm_bytes': max(w['hwm_bytes'] for w in workers),
                       'candidate_workers': workers,
                       'full_envelope_pass': None if model is None else True,
                       'measured_regression_branch_pass': True})
    for o in report['raw']:
        if o['kind'] == 'evidence' and o['role'] == 'candidate' and 'profile' in o['result']:
            profiles.append({'report': name, 'case': o['case']['name'], 'agg': o['case']['agg'],
                             'threads': o['threads'], 'groups': o['result']['groups'],
                             'public_parity': o['result']['parity'], 'profile': o['result']['profile'],
                             'pandas_index_construction_s': o['result']['pandas_index_construction_s']})
assert len(performance) == 36 and len(memory) == 30
assert len(all_raw) == 3540
assert len([m for m in memory if m['full_envelope_pass'] is None]) == 4

# Independent physical observers, not missing-profile substitutions.
audits = []
primary_arrays = Path(reports['sampler-primary-t4.json']['artifact_directory'])/'primary-max'
import numpy as np
primary_hashes = {f'k{i}': hashlib.sha256(np.load(primary_arrays/f'k{i}.npy', allow_pickle=False).tobytes()).hexdigest() for i in range(3)}
for threads in (1, 4):
    name = f'operation-audit-3828bb1-t{threads}.json'
    report = load(ROOT/name)
    assert report['status'] == 'AUDIT_PASS' and report['failures'] == [] and report['acceptance_usable'] is False
    assert len(report['observations']) == 20
    assert report['runtimes']['baseline']['manifest']['sha'] == BASE
    assert report['runtimes']['candidate']['manifest']['sha'] == CAND
    observations = []
    for o in report['observations']:
        q = o['result']
        assert q['rows'] == 5000000 and q['groups'] == 4901309 and q['parity'] == 'exact'
        assert {k:q['input_sha256'][k] for k in primary_hashes} == primary_hashes
        observations.append({'name': o['name'], 'events': o['events'], 'result': q})
    audits.append({'report': name, 'sha256': digest(ROOT/name), 'threads': threads,
                   'status': report['status'], 'observations': observations,
                   'scope': 'Physical declared observer sites; separate audit-only binaries. NaN-modified values, no acceptance timings/RSS.'})

refusals = []
for threads in (1,4):
    for agg in ('max','count'):
        name = f'resource-refusal-{agg}-t{threads}.json'
        q = load(ROOT/name)
        assert q['status'] == 'passed' and q['whole_process_cap'] is False and q['identity']['sha'] == CAND
        assert q['profile']['route_reason'] == 'memory_limit' and q['profile']['estimated_peak_bytes'] > 512*route.MIB
        refusals.append({'report': name, 'sha256': digest(ROOT/name), 'threads': threads, 'agg': agg,
                         'hwm_bytes': q['rss']['VmHWM'], 'modeled_bytes': q['profile']['estimated_peak_bytes'],
                         'scope': 'native profile-call HWM snapshot before output parity checks; not process-cap certification'})

# Preserve earlier stages rather than selecting only successful final observations.
history = []
for names_in_stage, source, label in [
    (['conversion-fused3-t1.json'], '5b91051c446d4bd8dfa5687d6e5c6d28cc19c47e', 'conversion-only RSS still failed'),
    (['final-primary-t4.json','final-controls-t4.json','final-fused3-t1.json'], '106ae1d07cd885fb1a661ea07d035608e27b5eaf', 'primary/RSS recovered but two new control failures'),
]:
    history.append({'source_sha': source, 'description': label, 'reports': [
        {'file': name, 'sha256': digest(ROOT/name), 'status': load(ROOT/name)['status'],
         'unmet_gates_unchanged': load(ROOT/name)['unmet_gates']} for name in names_in_stage]})
for directory in ('conversion-primary-probe','conversion-primary-probe-v2'):
    q = load(ROOT/directory/'report.json')
    history.append({'file': directory+'/report.json', 'sha256': digest(ROOT/directory/'report.json'),
                    'status': q['status'], 'observations': len(q['raw']), 'summary': q['summary'],
                    'startup_failures': sum('error' in o for o in q['raw']),
                    'scope': 'Four-pair exploration only; never acceptance. First harness rejected missing purpose before any ordinary call.'})
q = load(ROOT/'operation-audit-106ae1d-t1.json')
history.append({'file':'operation-audit-106ae1d-t1.json','sha256':digest(ROOT/'operation-audit-106ae1d-t1.json'),
                'status':q['status'],'observations':len(q['observations']),'scope':'Prior revision diagnostic, not pooled with final audits'})

runtimes = {
 'baseline-acceptance': Path('/tmp/pr20-resume-baseline-acceptance'),
 'conversion-acceptance': Path('/tmp/pr20-resume-conversion-acceptance'),
 '106ae1d-acceptance': Path('/tmp/pr20-resume-final-acceptance'),
 '3828bb1-acceptance': Path('/tmp/pr20-resume-sampler-acceptance'),
 'baseline-audit': Path('/tmp/pr20-resume-baseline-audit'),
 '106ae1d-audit': Path('/tmp/pr20-resume-final-audit'),
 '3828bb1-audit': Path('/tmp/pr20-resume-sampler-audit'),
}
archive = REPO/'benchmarks/evidence/issue17-recovery-raw.tar.gz'
assert not archive.exists(), 'Never overwrite a prior evidence archive'
manifest = []
with tarfile.open(archive, 'w:gz', compresslevel=9) as output:
    def add(path, name):
        output.add(path, arcname=name, recursive=False)
        manifest.append({'member':name, 'bytes':path.stat().st_size, 'sha256':digest(path)})
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.suffix in ('.py','.json','.log','.txt'):
            add(path, 'recovery/'+str(path.relative_to(ROOT)))
    for label, root in runtimes.items():
        for name in ('runtime.json','build.log','dependencies.lock','source.tar','operation-observers.json'):
            path = root/name
            if path.is_file():
                if name == 'build.log':
                    assert path.stat().st_size > 0
                add(path,'runtimes/'+label+'/'+name)
    for name in ('Cargo.lock','issue17-runtime.lock'):
        add(Path('/tmp/pr20-resume-original/locks')/name, 'locks/'+name)
    add(REPO/'benchmarks/evidence/issue17-oci-handoff.json','handoff/issue17-oci-handoff.json')
    payload = (json.dumps(manifest, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('manifest.json')
    entry.size = len(payload)
    output.addfile(entry, io.BytesIO(payload))

summary = {
 'schema':'pandas-booster.issue17.recovery.v1',
 'status':'DRAFT; targeted local performance/RSS failures recovered; NOT ready for certification/merge',
 'certified':False, 'baseline_sha':BASE, 'native_candidate_sha':CAND,
 'host':{'hardware':'Intel N100; x86_64; 4 physical cores; Linux 6.8.0-146-generic', 'measured_rayon_threads':[1,2,4], 'oci':False},
 'historical_record':{'source_summary':'benchmarks/evidence/issue17-n100-summary.json',
                       'archive':'benchmarks/evidence/issue17-n100-raw.tar.gz',
                       'archive_sha256':digest(REPO/'benchmarks/evidence/issue17-n100-raw.tar.gz'),
                       'verdict':'All historical failures, interrupted/quick observations and empty old build logs remain unchanged; do not reinterpret them as passes.'},
 'source_changes':[
  {'sha':'5b91051c446d4bd8dfa5687d6e5c6d28cc19c47e','change':'Transfer already ordered f64/i64 values Vec ownership into NumPy; retain permuted scatter.'},
  {'sha':'106ae1d07cd885fb1a661ea07d035608e27b5eaf','change':'Reuse packed keys for boundaries with checked lifetimes; share proven sorted-unique first Index levels; independent audit-only observer/provenance tooling and acceptance guards.'},
  {'sha':CAND,'change':'Replace rejection-only sample comparison sorting with bounded occupied-bit sampling; unchanged exact tuple hash and mandatory full-input proof.'}
 ],
 'method':{'pairs':40,'order':'adjacent alternating AB/BA','cold':'first ordinary public call','warm':'third ordinary public call after two untimed warmups',
           'bootstrap_draws':10000,'bootstrap_seed':42,'quantile':'one-sided nearest-rank U95 of paired bootstrap ratio of medians',
           'primary_T4':'warm ratio<=0.90 AND U95<1.00; cold U95<=1.05',
           'control_domain_T4':'cold/warm U95<=1.05',
           'additional_conservative_check':'primary warm U95<=0.90, reported separately; historical binding gate unchanged',
           'rss':'ten independent workers per version/case/reducer/thread combination; unchanged per-worker analytical-plus-overhead and measured envelopes'},
 'counts':{'timing_cells':len(performance),'timing_pairs':len(performance)*40,'ordinary_timing_workers':len(performance)*80,
           'profile_or_parity_workers':sum(o['kind']=='evidence' for o in all_raw),
           'rss_workers':sum(o['kind']=='rss' for o in all_raw),'raw_final_observations':len(all_raw),
           'independent_final_audit_workers':40},
 'runtimes':{role:capsule(reports[names[0]]['runtimes'][role]) for role in ('baseline','candidate')},
 'performance':performance,'memory':memory,'candidate_profiles':profiles,
 'independent_operation_audits':audits,'resource_refusal_diagnostics':refusals,
 'raw_reports':raw_reports,'intermediate_and_failed_observations':history,
 'diagnostic_index_allocation':{
  'scope':'Separate monkeypatched diagnostic only, not acceptance; four original/optimized max/count receipts retained',
  'reports':[name for name in ('index-original-max.json','index-original-count.json','index-optimized-max.json','index-optimized-count.json')],
  'result':'Exact pandas parity; approximately 318MB original versus 276MB optimized in a lighter-import diagnostic. Actual final isolated RSS is recorded above.'},
 'verification':{
  'cargo_test_locked':'236 passed, 1 ignored diagnostic; cargo test --locked',
  'diagnostic_probe':'cargo test --release sampler_recovery_probe -- --ignored --nocapture: 1 passed; all fifteen 20-call batches retained in sampler-recovery-probe.log',
  'sampler_probe_scope':'Representative SplitMix populations, not the binding RandomState42 data; sample-only control savings about1.25–1.48ms/call, not a causal claim for all control timing changes',
  'cargo_clippy':'cargo clippy --all-targets -- -D warnings: passed',
  'cargo_fmt':'cargo fmt --all -- --check: passed',
  'python_final_wheel':'PANDAS_BOOSTER_WHEEL_SMOKE=1 .venv/bin/python -m pytest tests/ -q --strict-markers -m "not stress" -o pythonpath=: 1058 passed, 1 intentional skip, 4 stress deselected, 43 warnings retained; installed extension hash matched final immutable acceptance wheel',
  'wheel_skip':'test_subprocess_pythonpath checkout-PYTHONPATH case intentionally skips in installed-wheel mode; separate .venv/bin/python -m pytest tests/test_subprocess_pythonpath.py -q --strict-markers -rs: 2 passed',
  'python_source_integration_before_sampler':'106ae1d source extension: 1059 passed, 4 deselected, 43 warnings',
  'minimum_pandas_final_wheel':'pandas1.5.0/numpy1.26.4: PANDAS_BOOSTER_WHEEL_SMOKE=1 /tmp/pr20-pandas150/bin/python -m pytest tests/test_index_dtype.py tests/groupby/test_multi_sort_first_route.py -q --strict-markers -o pythonpath=: 122 passed',
  'maximum_pandas_focused':'pandas2.3.3/numpy2.4.6 focused index/real-route tests: 122 passed; included in final full wheel suite',
  'audit_evidence_structural_tests':'151 passed after final three-key diagnostic refinement',
  'ruff':'ruff check python tests scripts benchmarks: passed',
  'basedpyright':'basedpyright --project pyrightconfig.json: 0 errors, 0 warnings, 0 notes',
  'release_contract':'check_release_contract.py metadata; workflow --file .github/workflows/publish.yml; supply-chain-workflow --file .github/workflows/supply-chain-audit.yml: passed',
  'diff_check':'git diff --check: passed before evidence generation',
  'adverse_test_receipts':'Initial uv sync timed out during project build; switched to no-install-project tooling. New purpose checks initially exposed 11 outdated retention fixtures (twice), corrected isolated mocks with independent guard coverage. Minimum-pandas run initially117passed/5failed due preexisting hardcoded int32 empty-index assertions; replaced with exact genuine pandas empty-frame aggregation references, approved independently, then122passed. A bare release-contract invocation lacked its required subcommand; proper metadata/workflow/supply-chain commands passed. Initial lint/type findings were corrected, not suppressed.',
  'miri':'Prior archive retains one exact sequential radix Miri pass; no new Miri run or threaded-production Miri qualification claimed'
 },
 'review_history':[
  'planner0 -> critic1 REQUEST CHANGES (audit isolation) -> planner revision -> critic1 APPROVE before product edits; explicit four-pair exploratory boundary approved',
  'native critic7 APPROVE ownership/packed/hash/resource safety; memory planner5 -> critic6 APPROVE plan and implementation including version-correct empty references',
  'audit critic8 APPROVE source method; noted collector/NaN gaps were filled and reviewed; primary-key fingerprint fixture delta approved',
  'control planner11 -> critic12 APPROVE before two-file sampler edits -> one bounded source probe -> critic12 APPROVE source freeze/new evidence',
  'Prior detailed plan file was unavailable in this lane; existing PR20 acceptance objective/receipt was continued, without creating a competing persisted plan',
  'Final independent artifact/publication review remains separate from these source approvals'
 ],
 'outstanding':[
  'OCI1/2/4/8/16/32/64 scaling, T32/T64 performance/control/domain/memory are still UNMEASURED. N100 is not OCI certification.',
  'Unsorted allocator/live-payload model remains UNKNOWN. All measured unsorted RSS workers pass the unchanged measured-regression branch, but the full min(analytical,measured) envelope cannot be certified without a valid model. No sorted model substituted.',
  'Baseline count profile export/phase timings remain unavailable. Separate independently operation-traced f64/i64 normal-call audits now establish physical hash/output-sort controls, not fabricated profile timings.',
  'Bounded subset reports intentionally remain DRAFT/incomplete; their candidate-bound union is not a completed single certification run.',
  'Bounded actual native-u64 tests do not establish >2**32-row behavior. No merge or issue17 closure is authorized.'
 ],
 'mac_authorization':load(REPO/'benchmarks/evidence/issue17-oci-handoff.json')['optional_mac_authorization'],
 'oci_handoff':'benchmarks/evidence/issue17-oci-handoff.json',
 'archive':{'path':str(archive.relative_to(REPO)), 'sha256':digest(archive),'bytes':archive.stat().st_size,
            'members':len(manifest)+1,
            'scope':'All new raw JSON requests/responses/reports, drivers/probes, dataset manifests, locks, observer patches, original source archives and nonempty new build transcripts. No failed report overwritten.',
            'omissions':'Large .npy arrays, compiled wheels/extensions and cargo targets are not embedded; immutable datasets/runtimes/binaries remain untouched at recorded /tmp paths, with hashes and deterministic generators. No claim of archival binary inclusion.'},
 'archive_manifest_member':'manifest.json',
}
output = REPO/'benchmarks/evidence/issue17-recovery-summary.json'
assert not output.exists(), 'Never silently overwrite a prior summary'
route.save(output,summary)
print(json.dumps({'summary':str(output), 'archive':summary['archive'], 'performance_cells':len(performance), 'memory_cells':len(memory)},indent=2))
