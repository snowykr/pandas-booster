"""Diagnostic-only monkeypatch; never acceptance performance or RSS evidence."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import pandas_booster
import pandas_booster._groupby_execution as execution

runtime = json.loads(Path(sys.argv[1]).read_text())
directory = Path(sys.argv[2])
agg, mode = sys.argv[3:5]

def rss():
    return {line.split(':')[0]: int(line.split()[1])*1024 for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('VmRSS:', 'VmHWM:'))}

report = {'purpose': 'diagnostic-only', 'runtime': runtime, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'agg': agg, 'mode': mode, 'stages': []}
report['stages'].append(['pre_input', rss()])
manifest = json.loads((directory/'dataset.json').read_text())
arrays = {Path(k).stem: np.load(directory/k) for k in manifest['files']}
frame = pd.DataFrame(arrays, copy=False)
original = pd.MultiIndex.from_arrays

def diagnostic_index(arrays, **kwargs):
    report['stages'].append(['pre_index', rss()])
    if mode == 'optimized' and len(arrays[0]) and np.all(arrays[0][1:] > arrays[0][:-1]):
        levels = [pd.Index(arrays[0], copy=False)]
        codes = [np.arange(len(arrays[0]), dtype=np.int64)]
        for a in arrays[1:]:
            cat = pd.Categorical(a)
            levels.append(cat.categories)
            codes.append(cat.codes)
            report['stages'].append(['factorized', rss()])
        idx = pd.MultiIndex(levels=levels, codes=codes, names=kwargs['names'], verify_integrity=False)
    else:
        idx = original(arrays, **kwargs)
    report['stages'].append(['post_index', rss()])
    return idx

pd.MultiIndex.from_arrays = diagnostic_index
out = frame.booster.groupby(['k0','k1','k2'], 'value', agg, sort=True)
report['rss'] = rss()
pd.MultiIndex.from_arrays = original
reference = getattr(frame.groupby(['k0','k1','k2'], sort=True)['value'], agg)()
pd.testing.assert_series_equal(out, reference, check_exact=True)
report['parity'] = True
Path(sys.argv[5]).write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'agg':agg, 'mode':mode, 'rss':report['rss'], 'stages':report['stages'], 'parity':True}))
