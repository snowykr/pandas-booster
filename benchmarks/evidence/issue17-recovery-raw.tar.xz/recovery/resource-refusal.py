"""Native 5m/10-key resource refusal diagnostic, never a process-cap claim."""
import importlib.util
import json
from pathlib import Path
import sys

spec = importlib.util.spec_from_file_location('route', sys.argv[1])
assert spec is not None and spec.loader is not None
route = importlib.util.module_from_spec(spec)
spec.loader.exec_module(route)
import numpy as np
import pandas_booster._rust as rust

runtime = json.loads(Path(sys.argv[2]).read_text())
agg, threads, output = sys.argv[3], int(sys.argv[4]), Path(sys.argv[5])
report = {'status': 'failed', 'diagnostic_only': True, 'whole_process_cap': False, 'kind': 'refused10_direct_kernel', 'n': 5000000, 'agg': agg, 'threads': threads, 'script_sha256': route.digest(Path(__file__)), 'driver_sha256': route.digest(Path(sys.argv[1]))}
try:
    report['identity'] = route.validate_runtime(runtime, threads)
    report['pre_input'] = route.rss()
    n = 5000000
    rng = np.random.RandomState(42)
    keys = [np.arange(n, dtype=np.int64)] + [rng.randint(0, 2, n, dtype=np.int64) for _ in range(9)]
    values = rng.randint(0, 10000, n, dtype=np.int64)
    out_keys, out_values, profile = getattr(rust, 'profile_groupby_multi_' + agg + '_i64_sorted')(keys, values)
    report.update(profile=profile, rss=route.rss(), output_groups=len(out_values))
    assert profile['route'] == 'hash_first'
    assert profile['route_reason'] == 'memory_limit'
    assert profile['estimated_peak_bytes'] > 512 * 1024 * 1024
    assert profile['hash_first_aggregation_count'] == 1
    assert profile['post_aggregation_sort_count'] == 1
    assert len(out_values) == n
    for original, actual in zip(keys, out_keys):
        np.testing.assert_array_equal(actual, original)
    if agg == 'max':
        np.testing.assert_array_equal(out_values, values)
    else:
        np.testing.assert_array_equal(out_values, np.ones(n, dtype=np.int64))
    report['status'] = 'passed'
finally:
    route.save(output, report)
print(json.dumps({'status': report['status'], 'agg': agg, 'threads': threads, 'rss': report['rss'], 'modeled_bytes': report['profile']['estimated_peak_bytes']}))
