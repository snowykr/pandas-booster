"""Four-pair full-size exploration only: never acceptance/certification."""
import importlib.util
import json
from pathlib import Path
import shutil
import sys

source = Path(sys.argv[1]).resolve()
root = Path(sys.argv[4]).resolve()
root.mkdir()
driver = root / 'worker.py'
shutil.copyfile(source, driver)
spec = importlib.util.spec_from_file_location('evidence', driver)
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
runtimes = {role: json.loads(Path(p).read_text()) for role, p in zip(('baseline', 'candidate'), sys.argv[2:4])}
for r in runtimes.values():
    e.validate_acceptance(r)
e.validate_comparison(runtimes)
report = {'status': 'EXPLORATORY_UNQUALIFIED', 'certified': False, 'purpose': 'source hypothesis selection only; four pairs cannot pass acceptance', 'driver_sha256': e.digest(driver), 'runtimes': runtimes, 'raw': [], 'summary': []}
e.save(root / 'report.json', report)
serial = 0
for case in [c for c in e.case_specs() if c['name'] == 'primary']:
    directory = root / ('primary-' + case['agg'])
    manifest = e.create_dataset(case, directory)
    samples = []
    for pair in range(4):
        values = {}
        order = ('baseline','candidate') if pair % 2 == 0 else ('candidate','baseline')
        for role in order:
            serial += 1
            request = {'purpose': 'acceptance', 'runtime': runtimes[role], 'case': case, 'dataset': str(directory), 'dataset_manifest': manifest, 'threads': 4, 'kind': 'warm', 'candidate': role == 'candidate'}
            req, res = root / (str(serial) + '-request.json'), root / (str(serial) + '-response.json')
            e.save(req, request)
            observation = {'case': case, 'pair': pair, 'role': role, 'kind': 'warm', 'threads': 4, 'request': str(req), 'response': str(res)}
            try:
                e.command([runtimes[role]['python'], '-I', str(driver), 'worker', str(req), str(res)], root, e.clean_env(4))
                result = json.loads(res.read_text())
                observation['result'] = result
                values[role] = result['elapsed_s']
            except Exception as error:
                observation['error'] = repr(error)
                if res.exists():
                    observation['result'] = json.loads(res.read_text())
            report['raw'].append(observation)
            e.save(root / 'report.json', report)
        if len(values) == 2:
            samples.append(values)
    if len(samples) == 4:
        summary = e.paired_summary(samples)
        summary.update(agg=case['agg'], threads=4, exploratory=True, acceptance=False)
        report['summary'].append(summary)
    e.save(root / 'report.json', report)
print(json.dumps(report['summary'], indent=2))
